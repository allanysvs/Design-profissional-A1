# Algoritmos e Processamento de Dados – 1º Semestre

Repositório dedicado aos estudos e atividades da disciplina de Algoritmos e Processamento de Dados.

## 📘 Conteúdos principais
- Lógica de programação
- Tipos de dados e variáveis
- Estruturas condicionais (if/else)
- Estruturas de repetição (while/for)
- Vetores e matrizes
- Funções e modularização
- Processamento de dados (entrada, tratamento e saída)

## 🧩 Tecnologias utilizadas
- VisualG / Portugol
- Python (opcional)

## 📂 Estrutura sugerida
- exercicios/
- projetos/
- atividades/

## 👨‍💻 Autor
Elisson Cavalcante da Silva
