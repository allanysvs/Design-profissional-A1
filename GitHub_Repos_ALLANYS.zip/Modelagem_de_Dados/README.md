# Modelagem de Dados – 1º Semestre

Repositório destinado aos conteúdos e atividades da disciplina de Modelagem de Dados.

## 📘 Conteúdos principais
- Entidades e atributos
- Relacionamentos
- Modelo Entidade-Relacionamento (MER)
- Normalização
- Diagramas (DER)
- Chaves primárias e estrangeiras

## 🛠 Ferramentas utilizadas
- Draw.io / Lucidchart
- MySQL Workbench

## 📂 Estrutura sugerida
- diagramas/
- atividades/
- exercicios/

## 👨‍💻 Autor
Elisson Cavalcante da Silva
