# Desenvolvimento Front-End – 1º Semestre

Atividades, projetos e estudos da disciplina de Desenvolvimento Front-End.

## 📘 Conteúdos principais
- HTML5
- CSS3
- JavaScript básico
- Estrutura de páginas web
- Formulários
- Responsividade

## 🛠 Tecnologias utilizadas
- HTML / CSS
- JavaScript
- VS Code

## 📂 Estrutura sugerida
- projetos/
- exercicios/
- aulas/

## 👨‍💻 Autor
Elisson Cavalcante da Silva
