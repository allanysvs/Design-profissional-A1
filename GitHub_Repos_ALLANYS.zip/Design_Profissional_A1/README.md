# Design Profissional – Evidências A1

Este repositório contém todas as entregas da A1 referentes à disciplina de Design Profissional.

## 📘 Entregáveis incluídos
- Currículo em LaTeX (PDF)
- Certificado de participação em evento
- Relato do processo seletivo
- Portfólio
- Repositórios das demais disciplinas do semestre

## 📂 Estrutura sugerida
- curriculo/
- certificados/
- processo_seletivo/
- portfolio/
- repositorios/

## 👨‍💻 Autor
Elisson Cavalcante da Silva
